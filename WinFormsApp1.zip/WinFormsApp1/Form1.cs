namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        string wynik;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var k1 = new Wezel(5);
            var k2 = new Wezel(3);
            var k3 = new Wezel(4);
            var k4 = new Wezel(1);
            var k5 = new Wezel(2);
            var k6 = new Wezel(7);

            k1.dzieci.Add(k2);
            k1.dzieci.Add(k3);
            k1.dzieci.Add(k4);

            k2.dzieci.Add(k5);
            k2.dzieci.Add(k6);

            A(k1);
        }

        void A(Wezel k)
        {
            wynik = "";
            foreach (var dziecko in k.dzieci)
            {
                wynik += k.wartosc;
                A(dziecko);
            }
            MessageBox.Show(wynik);

        }
    }
}