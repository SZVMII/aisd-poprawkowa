﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Węzeł
{
    internal class Knot3
    {
        public int value;
        public List<Knot3> childrenFIFO = new();


        public Knot3(int number)
        {
            this.value = number;
            this.childrenFIFO = new();
        }
    }

}
