using System.Text;

namespace Węzeł
{
    public partial class Form1 : Form
    {
        string result;
        public Form1()
        {
            InitializeComponent();
        }
        //Knot1 
        private void button1_Click(object sender, EventArgs e)
        {
            var node1 = new Knot(5);
            var node2 = new Knot(3);
            var node3 = new Knot(4);
            var node4 = new Knot(1);
            var node5 = new Knot(2);
            var node6 = new Knot(7);

            node1.childrenDFS.Add(node2);
            node1.childrenDFS.Add(node3);
            node1.childrenDFS.Add(node4);

            node2.childrenDFS.Add(node5);
            node2.childrenDFS.Add(node6);

            result = "";

            DFS(node1);
            MessageBox.Show(result.TrimEnd(", ".ToCharArray()));
        }
        //Knot2
        private void button2_Click(object sender, EventArgs e)
        {
            var node1 = new Knot2(5);
            var node21 = new Knot2(3);
            var node22 = new Knot2(2);
            var node31 = new Knot2(1);
            var node32 = new Knot2(4);
            var node33 = new Knot2(8);

            node1.Add(node21);
            node1.Add(node22);

            node21.Add(node31);
            node21.Add(node32);

            node22.Add(node33);

            result = "";
            visited.Clear();
            LIFO(node1);
            MessageBox.Show(result.TrimEnd(", ".ToCharArray()));
        }
        //Knot3
        private void button3_Click(object sender, EventArgs e)
        {
            var root = new Knot3(5);
            var node2 = new Knot3(3);
            var node3 = new Knot3(4);
            var node4 = new Knot3(1);
            var node5 = new Knot3(2);
            var node6 = new Knot3(7);


            root.childrenFIFO.Add(node2);
            root.childrenFIFO.Add(node3);
            node2.childrenFIFO.Add(node4);
            node2.childrenFIFO.Add(node5);
            node3.childrenFIFO.Add(node6);

            result = "";
            FIFOBFS(root);
            MessageBox.Show(result.TrimEnd(", ".ToCharArray()));
        }
        void DFS(Knot currentNode)
        {
            result += currentNode.value.ToString() + ", ";
            foreach (var child in currentNode.childrenDFS)
            {
                DFS(child);
            }
        }

        List<Knot2> visited = new();
        void LIFO(Knot2 currentNode)
        {
            result += currentNode.value.ToString() + ", ";
            visited.Add(currentNode);
            foreach (var neighbour in currentNode.neighbourhood)
            {
                if (!visited.Contains(neighbour))
                {
                    LIFO(neighbour);
                }
            }
        }

        void FIFOBFS(Knot3 root)
        {
            if (root == null)
                return;

            Queue<Knot3> queue = new Queue<Knot3>();
            queue.Enqueue(root);

            while (queue.Count != 0)
            {
                Knot3 currentNode = queue.Dequeue();
                result += currentNode.value.ToString() + ", ";

                foreach (Knot3 child in currentNode.childrenFIFO)
                {
                    queue.Enqueue(child);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Tworzenie drzewa BST i dodawanie elementów
            BinaryTree binaryTree = new BinaryTree(10);
            binaryTree.Add(5);
            binaryTree.Add(15);
            binaryTree.Add(3);
            binaryTree.Add(7);
            binaryTree.Add(12);
            binaryTree.Add(18);

            // Wypisanie wartości za pomocą PrintValuesInOrder (In-order Traversal)
            StringBuilder resultBuilder = new StringBuilder();
            binaryTree.PrintValuesInOrder(binaryTree.root, resultBuilder);

            // Wyświetlenie wyników w MessageBox
            MessageBox.Show(resultBuilder.ToString().TrimEnd(", ".ToCharArray()));
        }
    }
}