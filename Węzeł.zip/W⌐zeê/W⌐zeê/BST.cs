﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace Węzeł
{
    internal class BST
    {
        public int value;
        public List<BST> neighbourhood = new List<BST>();

        public BST(int number)
        {
            this.value = number;
        }
        public BST parent;
        public BST leftChild;
        public BST rightChild;

        public void AddChild(int number)
        {
            if (number <= this.value)
            {
                if (this.leftChild == null)
                {
                    this.leftChild = new BST(number);
                    this.leftChild.parent = this;
                }
                else
                {
                    this.leftChild.AddChild(number);
                }
            }
            else
            {
                if (this.rightChild == null)
                {
                    this.rightChild = new BST(number);
                    this.rightChild.parent = this;
                }
                else
                {
                    this.rightChild.AddChild(number);
                }
            }
        }
    }

    class BinaryTree
    {
        public BST root;
        public int nodeAmount;
        public BinaryTree(int number)
        {
            this.root = new BST(number);
            this.nodeAmount = 1;
        }
        public void PrintValuesInOrder(BST node, StringBuilder resultBuilder)
        {
            if (node != null)
            {
                PrintValuesInOrder(node.leftChild, resultBuilder);
                resultBuilder.Append(node.value.ToString() + ", ");
                PrintValuesInOrder(node.rightChild, resultBuilder);
            }
        }

        public BST FindParent(int number)
        {
            var currentNode = this.root;
            BST parent = null;
            while (currentNode != null)
            {
                parent = currentNode;

                if (number < currentNode.value)
                {
                    currentNode = currentNode.leftChild;

                }
                else
                {
                    currentNode = currentNode.rightChild;
                }
            }
            return parent;
        }

        public void Add(int number)
        {
            var parent = this.FindParent(number);
            parent.AddChild(number);
        }

        public void InOrderTraversal(BST node)
        {
            if (node != null)
            {
                InOrderTraversal(node.leftChild);
                Console.WriteLine(node.value);
                InOrderTraversal(node.rightChild);
            }
        }
    }
}
