﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Węzeł
{
    internal class Knot
    {
        public int value;
        public List<Knot> childrenDFS = new List<Knot>();
        public Knot(int number)
        {
            this.value = number;
        }

    }
}
