﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Węzeł
{
    internal class Knot2
    {
        public int value;
        public List<Knot2> neighbourhood = new List<Knot2>();

        public Knot2(int liczba)
        {
            this.value = liczba;
        }
        public void Add(Knot2 node)
        {
            this.neighbourhood.Add(node);
            node.neighbourhood.Add(this);
        }
    }
}
